var cat , catImage;
var mouse , mouseImage;
var garden , gardenImage;

function preload() {
catImg = loadImage("cat.png");
mouseImg = loadImage("mouse.png");
gardenImg = loadImage("garden.png");

}

function setup(){
    createCanvas(1000,800);
    
}

function draw() {

    background(255);
    //Write condition here to evalute if tom and jerry collide

    drawSprites();
}


function keyPressed(){

if(keyCode===LEFT_ARROW){
cat.velocityx = -5;
cat.addAnimation("catRunning" , catImg2);
cat.changeAnimation("catRunning");


  }

}
